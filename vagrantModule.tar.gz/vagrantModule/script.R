#!/usr/bin/Rscript
x <- rnorm(10)
saveRDS(x, file = "x.rds")
