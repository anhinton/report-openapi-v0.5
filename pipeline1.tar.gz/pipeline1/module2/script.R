#!/usr/bin/Rscript
numbers <- readRDS("numbers.rds")
plot(numbers)
